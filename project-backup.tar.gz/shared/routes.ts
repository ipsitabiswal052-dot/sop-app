import { z } from 'zod';
import { insertBatchSchema, insertSopLogSchema, sopLogs } from './schema';

// This file defines the API types, but the implementation will use LocalStorage as requested.

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  // These routes are defined for structure but the frontend will primarily use LocalStorage
  batches: {
    list: {
      method: 'GET' as const,
      path: '/api/batches',
      responses: {
        200: z.array(z.string()), // Returns list of batch IDs
      },
    },
    logs: {
      method: 'GET' as const,
      path: '/api/batches/:id/logs',
      responses: {
        200: z.array(z.custom<typeof sopLogs.$inferSelect>()),
      },
    },
    logStep: {
      method: 'POST' as const,
      path: '/api/logs',
      input: insertSopLogSchema,
      responses: {
        201: z.custom<typeof sopLogs.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
