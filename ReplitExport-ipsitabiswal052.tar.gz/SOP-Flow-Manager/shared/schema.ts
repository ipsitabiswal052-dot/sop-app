import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// We define the schema for type safety, even if strictly using LocalStorage as requested.

export const batches = pgTable("batches", {
  id: serial("id").primaryKey(),
  batchId: text("batch_id").notNull(), // The user-entered Product/Batch ID
  status: text("status").notNull().default("active"), // active, completed
  createdAt: timestamp("created_at").defaultNow(),
});

export const sopLogs = pgTable("sop_logs", {
  id: serial("id").primaryKey(),
  batchId: text("batch_id").notNull(),
  sectionId: integer("section_id").notNull(),
  stepId: integer("step_id").notNull(),
  stepName: text("step_name").notNull(),
  requiredRole: text("required_role").notNull(),
  
  completedBy: text("completed_by").notNull(),
  userRole: text("user_role").notNull(),
  workDate: text("work_date").notNull(), // User selected date
  documentName: text("document_name"), // Name of uploaded file
  
  status: text("status").notNull().default("completed"),
  loggedAt: timestamp("logged_at").defaultNow(),
});

export const insertBatchSchema = createInsertSchema(batches).omit({ id: true, createdAt: true });
export const insertSopLogSchema = createInsertSchema(sopLogs).omit({ id: true, loggedAt: true });

export type Batch = typeof batches.$inferSelect;
export type InsertBatch = z.infer<typeof insertBatchSchema>;
export type SopLog = typeof sopLogs.$inferSelect;
export type InsertSopLog = z.infer<typeof insertSopLogSchema>;

// Types for LocalStorage Data Structure
export interface LocalStorageBatch {
  batchId: string;
  logs: SopLog[];
}

export const ROLES = [
  "Store",
  "Lab",
  "Accounts",
  "Production",
  "Sales",
  "Audit",
  "Admin"
] as const;

export type UserRole = typeof ROLES[number];

export const SOP_SECTIONS = [
  {
    id: 1,
    title: "PURCHASE PROCESS SOP",
    steps: [
      { id: 1, name: "Ask for Test Report", role: "Store", docRequired: true },
      { id: 2, name: "Get Test Report Approved from In-house Lab", role: "Lab", docRequired: true },
      { id: 3, name: "Ask for Quotation / Price", role: "Store", docRequired: true },
      { id: 4, name: "Approve Pricing", role: "Accounts", docRequired: true },
      { id: 5, name: "Issue Purchase Order with Quantity", role: "Accounts", docRequired: true },
      { id: 6, name: "Get Transporter Quote (if required)", role: "Store", docRequired: true },
      { id: 7, name: "Pay Advance to Vendor", role: "Accounts", docRequired: true },
      { id: 8, name: "Pay Advance to Transporter (if required)", role: "Accounts", docRequired: true },
      { id: 9, name: "Dispatch to Factory", role: "Store", docRequired: true },
      { id: 10, name: "Arrival at Factory", role: "Store", docRequired: true },
    ]
  },
  {
    id: 2,
    title: "PURCHASE RECEIVING & QC SOP",
    steps: [
      { id: 1, name: "Unloading (Office Hours Only)", role: "Store", docRequired: false },
      { id: 2, name: "Quantity Check & Lab Sample Submission (before 9:30 AM)", role: "Store", docRequired: true },
      { id: 3, name: "QC Check at Lab (by 12:00 PM)", role: "Lab", docRequired: true },
      { id: 4, name: "Compare Test Report", role: "Lab", docRequired: false },
      { id: 5, name: "Prepare Test Deviation Report (if any)", role: "Lab", docRequired: true },
      { id: 6, name: "Issue GRN / Purchase Receive Note", role: "Accounts", docRequired: true },
      { id: 7, name: "Bill Filing", role: "Accounts", docRequired: true },
      { id: 8, name: "Payment Decision", role: "Accounts", docRequired: true },
      { id: 9, name: "Accounting Stocking in Store", role: "Accounts", docRequired: false },
      { id: 10, name: "Documentation Completion", role: "Accounts", docRequired: true },
    ]
  },
  {
    id: 3,
    title: "BATCH PROCESSING SOP (8 AM – 3 PM)",
    steps: [
      { id: 1, name: "Issue Production Instruction Card (Previous Day)", role: "Production", docRequired: true },
      { id: 2, name: "Store Issues Required Quantity Material", role: "Store", docRequired: false },
      { id: 3, name: "Additional Material Issue by Plant Head (if required)", role: "Production", docRequired: true },
      { id: 4, name: "Update Production Instruction Card", role: "Production", docRequired: false },
      { id: 5, name: "Issue Additional Material & Reprocess if Needed", role: "Production", docRequired: false },
    ]
  },
  {
    id: 4,
    title: "COMPLETION OF BATCH SOP (3 PM – 6 PM)",
    steps: [
      { id: 1, name: "Sample of Finished Goods Sent to Lab", role: "Production", docRequired: false },
      { id: 2, name: "Lab Testing", role: "Lab", docRequired: true },
      { id: 3, name: "Batch Process Card Completed Next Day (10 AM)", role: "Production", docRequired: true },
      { id: 4, name: "Packaging (Next Day)", role: "Production", docRequired: false },
      { id: 5, name: "Labeling (Next Day)", role: "Production", docRequired: false },
      { id: 6, name: "Dead Stock Handling", role: "Store", docRequired: true },
    ]
  },
  {
    id: 5,
    title: "COSTING SOP",
    steps: [
      { id: 1, name: "Process Batch Costing as per BRC", role: "Accounts", docRequired: true },
      { id: 2, name: "Entry in Inventory Assemblies", role: "Accounts", docRequired: false },
      { id: 3, name: "Process Packing Assemblies", role: "Accounts", docRequired: false },
      { id: 4, name: "Share Average Costing", role: "Accounts", docRequired: true },
    ]
  },
  {
    id: 6,
    title: "SALES SOP",
    steps: [
      { id: 1, name: "Prepare Quotation / Proforma Invoice", role: "Sales", docRequired: true },
      { id: 2, name: "Receive Purchase Order", role: "Sales", docRequired: true },
      { id: 3, name: "Receive Payment", role: "Accounts", docRequired: true },
      { id: 4, name: "Generate Bill", role: "Accounts", docRequired: true },
      { id: 5, name: "Generate E-Way Bill", role: "Accounts", docRequired: true },
      { id: 6, name: "Dispatch", role: "Store", docRequired: true },
    ]
  },
  {
    id: 7,
    title: "AUDIT SOP",
    steps: [
      { id: 1, name: "Verify SOP Compliance", role: "Audit", docRequired: false },
      { id: 2, name: "Check Document Completeness", role: "Audit", docRequired: false },
      { id: 3, name: "Review Deviations & Approvals", role: "Audit", docRequired: true },
      { id: 4, name: "Final Audit Sign-off", role: "Audit", docRequired: true },
    ]
  }
];
